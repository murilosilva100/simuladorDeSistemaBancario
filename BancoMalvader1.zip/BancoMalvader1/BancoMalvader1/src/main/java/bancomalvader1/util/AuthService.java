package bancomalvader1.util;

import lombok.Getter;
import lombok.Setter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthService {

    @Getter
    @Setter
    private static int userIdLogado;

    public static boolean verificarLogin(String cpf, String senha) {
        String query = "SELECT senha_hash FROM usuario WHERE cpf = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String senhaHashArmazenada = rs.getString("senha_hash");

                String senhaDigitadaHash = MD5Util.hashMD5(senha);

                if (senhaHashArmazenada.equals(senhaDigitadaHash)) {
                    System.out.println("[SUCESSO] Login bem-sucedido para o CPF: " + cpf);
                    return true;
                } else {
                    System.out.println("Senha incorreta para o CPF: " + cpf);
                    return false;
                }
            } else {
                System.out.println("Usuário com CPF " + cpf + " não encontrado.");
                return false;
            }

        } catch (SQLException e) {
            System.err.println("Erro ao verificar login: " + e.getMessage());
            return false;
        }
    }

    public static String getTipoUsuario(String cpf) {
        String sql = "SELECT tipo_usuario FROM usuario WHERE cpf = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getString("tipo_usuario") : null;
        } catch (SQLException e) {
            System.out.println("[ERRO] Ao obter tipo de usuário: " + e.getMessage());
            return null;
        }
    }

    public static int getUserIdByCpf(String cpf) {
        String sql = "SELECT id_usuario FROM usuario WHERE cpf = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("id_usuario") : -1;
        } catch (SQLException e) {
            System.out.println("[ERRO] Ao obter ID do usuário: " + e.getMessage());
            return -1;
        }
    }

}