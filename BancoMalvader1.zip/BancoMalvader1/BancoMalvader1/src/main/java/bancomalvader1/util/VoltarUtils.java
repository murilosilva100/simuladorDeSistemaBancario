package bancomalvader1.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.Stack;

public class VoltarUtils {
    private static final Stack<String> historicoFXML = new Stack<>();

    public static void guardarTela(String fxmlPath) {
        historicoFXML.push(fxmlPath);
    }

    public static void voltar(Parent telaAtual) {
        if (!historicoFXML.isEmpty()) {
            try {
                String fxmlAnterior = historicoFXML.pop();
                Parent root = FXMLLoader.load(VoltarUtils.class.getResource(fxmlAnterior));
                Stage stage = (Stage) telaAtual.getScene().getWindow();
                stage.setScene(new Scene(root));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Não há telas no histórico para voltar");
        }
    }
}