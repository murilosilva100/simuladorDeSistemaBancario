package bancomalvader1.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/bancomalvaderbm";
    private static final String USER = "root";
    private static final String PASS = "pc1704@";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Driver MySQL não encontrado", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static boolean isConnected() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            return true; // Conexão bem-sucedida
        } catch (SQLException e) {
            System.out.println("Falha na conexão: " + e.getMessage());
            return false;
        }
    }
}