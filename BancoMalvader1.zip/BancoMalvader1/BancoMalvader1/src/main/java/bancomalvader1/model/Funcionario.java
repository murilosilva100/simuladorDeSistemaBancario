package bancomalvader1.model;

public class Funcionario {
    private int idFuncionario;
    private int idUsuario;
    private String codigoFuncionario;
    private Cargo cargo;
    private Integer idSupervisor;

    public enum Cargo {
        ESTAGIARIO, ATENDENTE, GERENTE
    }

    // Construtor vazio
    public Funcionario() {
    }

    // Construtor com todos os campos
    public Funcionario(int idFuncionario, int idUsuario, String codigoFuncionario, Cargo cargo, Integer idSupervisor) {
        this.idFuncionario = idFuncionario;
        this.idUsuario = idUsuario;
        this.codigoFuncionario = codigoFuncionario;
        this.cargo = cargo;
        this.idSupervisor = idSupervisor;
    }

    // Getters e Setters
    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getCodigoFuncionario() {
        return codigoFuncionario;
    }

    public void setCodigoFuncionario(String codigoFuncionario) {
        this.codigoFuncionario = codigoFuncionario;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public Integer getIdSupervisor() {
        return idSupervisor;
    }

    public void setIdSupervisor(Integer idSupervisor) {
        this.idSupervisor = idSupervisor;
    }
}
