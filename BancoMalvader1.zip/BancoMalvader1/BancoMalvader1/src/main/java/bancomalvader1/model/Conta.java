package bancomalvader1.model;

import java.time.LocalDateTime;

public class Conta {
    private int idConta;
    private String numeroConta;
    private int idAgencia;
    private double saldo;
    private TipoConta tipoConta;
    private int idCliente;
    private LocalDateTime dataAbertura;
    private StatusConta status;

    public enum TipoConta {
        POUPANCA, CORRENTE, INVESTIMENTO
    }

    public enum StatusConta {
        ATIVA, ENCERRADA, BLOQUEADA
    }

    // Construtor vazio
    public Conta() {
    }

    // Construtor com todos os campos
    public Conta(int idConta, String numeroConta, int idAgencia, double saldo,
                 TipoConta tipoConta, int idCliente, LocalDateTime dataAbertura, StatusConta status) {
        this.idConta = idConta;
        this.numeroConta = numeroConta;
        this.idAgencia = idAgencia;
        this.saldo = saldo;
        this.tipoConta = tipoConta;
        this.idCliente = idCliente;
        this.dataAbertura = dataAbertura;
        this.status = status;
    }

    // Getters e Setters
    public int getIdConta() {
        return idConta;
    }

    public void setIdConta(int idConta) {
        this.idConta = idConta;
    }

    public String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

    public int getIdAgencia() {
        return idAgencia;
    }

    public void setIdAgencia(int idAgencia) {
        this.idAgencia = idAgencia;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public TipoConta getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(TipoConta tipoConta) {
        this.tipoConta = tipoConta;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public LocalDateTime getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(LocalDateTime dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public StatusConta getStatus() {
        return status;
    }

    public void setStatus(StatusConta status) {
        this.status = status;
    }
}
