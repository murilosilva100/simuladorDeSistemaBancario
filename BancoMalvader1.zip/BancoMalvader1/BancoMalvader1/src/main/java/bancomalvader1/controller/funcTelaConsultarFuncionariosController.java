package bancomalvader1.controller;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import bancomalvader1.util.Database;
import javafx.scene.control.TextArea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class funcTelaConsultarFuncionariosController {

    @FXML private TextField txtNomeFuncionario;
    @FXML private TextField txtCpfFuncionario;
    @FXML private TextArea txtResultado;
    @FXML private Button btnConsultarFuncionario;
    @FXML private Button btnSair;

    @FXML
    private void initialize() {
        btnConsultarFuncionario.setOnAction(event -> consultarFuncionario());
    }

    private void consultarFuncionario() {
        String nome = txtNomeFuncionario.getText().trim();
        String cpf = txtCpfFuncionario.getText().trim();

        if (nome.isEmpty() || cpf.isEmpty()) {
            txtResultado.setText("Preencha o nome e o CPF do funcionário.");
            return;
        }

        String sql = """
            SELECT 
                u.id_usuario, u.nome, u.cpf,
                f.id_funcionario, f.codigo_funcionario, f.cargo, f.id_supervisor,
                e.cep, e.local, e.numero_casa, e.bairro, e.cidade, e.estado, e.complemento
            FROM usuario u
            JOIN funcionario f ON u.id_usuario = f.id_usuario
            LEFT JOIN endereco e ON u.id_usuario = e.id_usuario
            WHERE u.nome = ? AND u.cpf = ?
        """;

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, cpf);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    StringBuilder sb = new StringBuilder();

                    sb.append("=== DADOS DO FUNCIONÁRIO ===\n\n");
                    sb.append("Nome: ").append(rs.getString("nome")).append("\n");
                    sb.append("CPF: ").append(rs.getString("cpf")).append("\n");
                    sb.append("Cargo: ").append(rs.getString("cargo")).append("\n");
                    sb.append("Código: ").append(rs.getString("codigo_funcionario")).append("\n");

                    sb.append("Supervisor: ").append(rs.getString("id_supervisor")).append("\n");

                    sb.append("\n=== ENDEREÇO ===\n");
                    sb.append("CEP: ").append(rs.getString("cep")).append("\n");
                    sb.append("Local: ").append(rs.getString("local")).append("\n");
                    sb.append("Número: ").append(rs.getInt("numero_casa")).append("\n");
                    sb.append("Bairro: ").append(rs.getString("bairro")).append("\n");
                    sb.append("Cidade: ").append(rs.getString("cidade")).append("\n");
                    sb.append("Estado: ").append(rs.getString("estado")).append("\n");
                    String complemento = rs.getString("complemento");
                    if (complemento != null && !complemento.isEmpty()) {
                        sb.append("Complemento: ").append(complemento).append("\n");
                    }

                    txtResultado.setText(sb.toString());

                } else {
                    txtResultado.setText("Funcionário não encontrado com os dados informados.");
                }
            }

        } catch (SQLException e) {
            txtResultado.setText("Erro ao consultar funcionário.");
            e.printStackTrace();
        }
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
