package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class funcTelaConsultarClientesController {

    @FXML private TextField txtCpfCliente;
    @FXML private TextField txtNomeCliente;
    @FXML private Button btnConsultarCliente;
    @FXML private Button btnSair;
    @FXML private TextArea txtResultado;


    @FXML
    private void initialize() {
        btnConsultarCliente.setOnAction(event -> consultarCliente());
    }

    private void consultarCliente() {
        String nome = txtNomeCliente.getText().trim();
        String cpf = txtCpfCliente.getText().trim();

        if (nome.isEmpty() || cpf.isEmpty()) {
            mostrarAlerta("Erro", "Por favor, preencha o nome e o CPF.");
            return;
        }

        String sql = """
            SELECT u.id_usuario, u.nome, u.cpf, u.telefone, c.score_credito,
                   e.cep, e.local, e.numero_casa, e.bairro, e.cidade, e.estado, e.complemento
            FROM usuario u
            JOIN cliente c ON c.id_usuario = u.id_usuario
            LEFT JOIN endereco e ON e.id_usuario = u.id_usuario
            WHERE u.nome = ? AND u.cpf = ?
        """;

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, cpf);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    StringBuilder sb = new StringBuilder();

                    sb.append("========== DADOS DO CLIENTE =======\n\n");
                    sb.append("ID Usuário: ").append(rs.getInt("id_usuario")).append("\n");
                    sb.append("Nome: ").append(rs.getString("nome")).append("\n");
                    sb.append("CPF: ").append(rs.getString("cpf")).append("\n");
                    sb.append("Telefone: ").append(rs.getString("telefone")).append("\n");
                    sb.append("Score de Crédito: ").append(rs.getDouble("score_credito")).append("\n\n");

                    sb.append("\n============= ENDEREÇO ===========\n");
                    sb.append("CEP: ").append(rs.getString("cep")).append("\n");
                    sb.append("Logradouro: ").append(rs.getString("local")).append(", ")
                            .append(rs.getInt("numero_casa")).append("\n");
                    sb.append("Bairro: ").append(rs.getString("bairro")).append("\n");
                    sb.append("Cidade: ").append(rs.getString("cidade")).append(" - ")
                            .append(rs.getString("estado")).append("\n");
                    sb.append("Complemento: ").append(rs.getString("complemento") != null ?
                            rs.getString("complemento") : "N/A");

                    txtResultado.setText(sb.toString());
                } else {
                    txtResultado.setText("Cliente não encontrado.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Erro ao consultar cliente.");
        }
    }

    private void mostrarAlerta(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
