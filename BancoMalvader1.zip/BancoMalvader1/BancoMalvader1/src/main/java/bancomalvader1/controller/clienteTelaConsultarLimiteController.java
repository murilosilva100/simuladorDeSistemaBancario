package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;

public class clienteTelaConsultarLimiteController {

    @FXML private TextField txtContaLimite;
    @FXML private Label lblLimite;
    @FXML private Button btnConsultarLimite;

    @FXML
    private void initialize() {
        btnConsultarLimite.setOnAction(e -> consultarLimite());
    }

    private void consultarLimite() {
        String numeroConta = txtContaLimite.getText().trim();
        lblLimite.setText("Limite: ()"); // reset visual

        if (numeroConta.isEmpty()) {
            alertErro("Informe o número da conta.");
            return;
        }

        String sqlConta = "SELECT id_conta, tipo_conta, status FROM conta WHERE numero_conta = ?";
        String sqlLimite = "SELECT limite FROM conta_corrente WHERE id_conta = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement psConta = conn.prepareStatement(sqlConta)) {

            psConta.setString(1, numeroConta);
            ResultSet rsConta = psConta.executeQuery();

            if (!rsConta.next()) {
                alertErro("Conta não encontrada.");
                return;
            }

            int idConta = rsConta.getInt("id_conta");
            String tipoConta = rsConta.getString("tipo_conta");
            String status = rsConta.getString("status");

            if (!"CORRENTE".equalsIgnoreCase(tipoConta)) {
                alertErro("Apenas contas do tipo CORRENTE possuem limite.");
                return;
            }

            if (!"ATIVA".equalsIgnoreCase(status)) {
                alertErro("Conta está " + status.toLowerCase() + ". Não é possível consultar o limite.");
                return;
            }

            try (PreparedStatement psLimite = conn.prepareStatement(sqlLimite)) {
                psLimite.setInt(1, idConta);
                ResultSet rsLimite = psLimite.executeQuery();

                if (rsLimite.next()) {
                    double limite = rsLimite.getDouble("limite");
                    NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
                    lblLimite.setText("Limite: " + nf.format(limite));
                } else {
                    lblLimite.setText("Limite: (não definido)");
                }
            }

        } catch (SQLException e) {
            alertErro("Erro na consulta: " + e.getMessage());
        }
    }

    private void alertErro(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
