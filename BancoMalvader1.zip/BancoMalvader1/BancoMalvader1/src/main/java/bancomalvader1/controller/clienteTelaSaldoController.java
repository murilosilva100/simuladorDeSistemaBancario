package bancomalvader1.controller;

import bancomalvader1.util.AuthService;
import bancomalvader1.util.Database;
import bancomalvader1.util.MD5Util;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class clienteTelaSaldoController {

    @FXML private TextField txtNumeroConta;
    @FXML private TextField txtIdCliente;
    @FXML private Label lblResultadoSaldo;
    @FXML private Button btnConsultarSaldo;

    @FXML
    private void initialize() {
        // Define ação do botão consultar
        btnConsultarSaldo.setOnAction(event -> consultarSaldo());
    }

    private void consultarSaldo() {
        String numeroConta = txtNumeroConta.getText().trim();
        String idClienteStr = txtIdCliente.getText().trim();

        if (numeroConta.isEmpty() || idClienteStr.isEmpty()) {
            mostrarErro("Preencha todos os campos.");
            return;
        }

        try {
            int idCliente = Integer.parseInt(idClienteStr);

            String sql = "SELECT saldo FROM conta WHERE numero_conta = ? AND id_cliente = ? AND status = 'ATIVA'";
            try (Connection conn = Database.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, numeroConta);
                stmt.setInt(2, idCliente);

                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    double saldo = rs.getDouble("saldo");
                    lblResultadoSaldo.setText(String.format("Saldo: R$ %.2f", saldo));
                } else {
                    lblResultadoSaldo.setText("Conta não encontrada ou inativa.");
                }
            }

        } catch (NumberFormatException e) {
            mostrarErro("ID do cliente deve ser numérico.");
        } catch (SQLException e) {
            mostrarErro("Erro ao consultar saldo: " + e.getMessage());
        }
    }

    private void mostrarErro(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText("Problema na consulta");
        alert.setContentText(mensagem);
        alert.showAndWait();
    }


    @FXML private AnchorPane rootPane;
    @FXML private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }
}
