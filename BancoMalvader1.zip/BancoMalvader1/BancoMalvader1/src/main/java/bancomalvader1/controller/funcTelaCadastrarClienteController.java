package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class funcTelaCadastrarClienteController {

    @FXML private TextField txtIdUsuario;
    @FXML private TextField txtScoreCliente;
    @FXML private Button btnAdicionarCliente;

    @FXML
    public void initialize() {
        // Se necessário, inicializações ao carregar a tela
        btnAdicionarCliente.setOnAction(e -> adicionarCliente());
    }

    private void adicionarCliente() {
        String idUsuarioStr = txtIdUsuario.getText();
        String scoreStr = txtScoreCliente.getText();

        if (idUsuarioStr.isEmpty() || scoreStr.isEmpty()) {
            mostrarAlertaErro("Preencha todos os campos.");
            return;
        }

        try {
            int idUsuario = Integer.parseInt(idUsuarioStr);
            double score = Double.parseDouble(scoreStr);

            String sql = "INSERT INTO cliente (id_usuario, score_credito) VALUES (?, ?)";

            try (Connection conn = Database.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, idUsuario);
                stmt.setDouble(2, score);
                stmt.executeUpdate();

                mostrarAlertaSucesso("Cliente cadastrado com sucesso!");
                limparCampos();
            }

        } catch (NumberFormatException e) {
            mostrarAlertaErro("ID e Score devem ser numéricos.");
        } catch (SQLException e) {
            mostrarAlertaErro("Erro ao inserir cliente: " + e.getMessage());
        }
    }

    private void limparCampos() {
        txtIdUsuario.clear();
        txtScoreCliente.clear();
    }

    private void mostrarAlertaSucesso(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sucesso");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void mostrarAlertaErro(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText("Operação falhou");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
