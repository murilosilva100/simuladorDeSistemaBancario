package bancomalvader1.controller;



import bancomalvader1.util.Database;
import bancomalvader1.util.MD5Util;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.*;


public class funcTelaAlterarUsuarioController {

    @FXML private TextField txtIdUsuario;
    @FXML private TextField txtNomeUsuario;
    @FXML private TextField txtDataNascimento;
    @FXML private TextField txtSenhaUsuario;
    @FXML private TextField txtTelefone; // campo telefone no FXML
    @FXML private TextField txtOtpAtivo;
    @FXML private TextField txtOtpExpiracao;
    @FXML private ComboBox<String> comboTipoUsuario;

    @FXML
    public void initialize() {
        comboTipoUsuario.getItems().addAll("CLIENTE", "FUNCIONARIO");
    }

    @FXML
    public void onLimparCampos() {
        txtIdUsuario.clear();
        txtNomeUsuario.clear();
        txtDataNascimento.clear();
        txtSenhaUsuario.clear();
        txtTelefone.clear();
        txtOtpAtivo.clear();
        txtOtpExpiracao.clear();
        comboTipoUsuario.getSelectionModel().clearSelection();
    }

    @FXML
    public void alterarUsuario() {
        int id;
        try {
            id = Integer.parseInt(txtIdUsuario.getText());
        } catch (NumberFormatException e) {
            showAlert("Erro", "ID inválido!", AlertType.ERROR);
            return;
        }

        // Buscar dados atuais
        String sqlSelect = "SELECT * FROM usuario WHERE id_usuario = ?";
        String sqlUpdate = """
            UPDATE usuario SET nome = ?, senha_hash = ?, tipo_usuario = ?, 
                data_nascimento = ?, telefone = ?, otp_ativo = ?, otp_expiracao = ?
            WHERE id_usuario = ?
            """;

        try (Connection conn = Database.getConnection();
             PreparedStatement psSelect = conn.prepareStatement(sqlSelect);
             PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)) {

            psSelect.setInt(1, id);
            ResultSet rs = psSelect.executeQuery();

            if (!rs.next()) {
                showAlert("Erro", "Usuário não encontrado!", AlertType.ERROR);
                return;
            }

            // Campos obrigatórios
            String nome = txtNomeUsuario.getText().isBlank() ? rs.getString("nome") : txtNomeUsuario.getText();
            String senha = txtSenhaUsuario.getText().isBlank() ? rs.getString("senha_hash") :
                    MD5Util.hashMD5(txtSenhaUsuario.getText());

            String tipo = comboTipoUsuario.getValue() == null ? rs.getString("tipo_usuario") : comboTipoUsuario.getValue();

            // Campos opcionais
            String dataNascimento = txtDataNascimento.getText().isBlank() ? rs.getString("data_nascimento") : txtDataNascimento.getText();
            String telefone = txtTelefone.getText().isBlank() ? rs.getString("telefone") : txtTelefone.getText();
            String otpAtivo = txtOtpAtivo.getText().isBlank() ? rs.getString("otp_ativo") : txtOtpAtivo.getText();
            String otpExpiracao = txtOtpExpiracao.getText().isBlank() ? rs.getString("otp_expiracao") : txtOtpExpiracao.getText();

            // Preencher statement
            psUpdate.setString(1, nome);
            psUpdate.setString(2, senha);
            psUpdate.setString(3, tipo);
            psUpdate.setString(4, dataNascimento);
            psUpdate.setString(5, telefone);
            psUpdate.setString(6, otpAtivo);
            psUpdate.setString(7, otpExpiracao);
            psUpdate.setInt(8, id);

            int linhasAfetadas = psUpdate.executeUpdate();

            if (linhasAfetadas > 0) {
                showAlert("Sucesso", "Usuário atualizado com sucesso!", AlertType.INFORMATION);
                onLimparCampos();
            } else {
                showAlert("Erro", "Nenhuma linha foi atualizada.", AlertType.ERROR);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erro de SQL", e.getMessage(), AlertType.ERROR);
        }
    }

    private void showAlert(String titulo, String mensagem, AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
