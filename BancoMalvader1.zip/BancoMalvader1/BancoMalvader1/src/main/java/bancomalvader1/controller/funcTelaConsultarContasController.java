package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.*;

public class funcTelaConsultarContasController {

    @FXML private TextField txtNumeroConta;
    @FXML private TextArea txtResultado;
    @FXML private Button btnConsultarConta;

    @FXML
    private void initialize() {
        btnConsultarConta.setOnAction(event -> consultarConta());
    }


    private void consultarConta() {
        String numeroConta = txtNumeroConta.getText().trim();

        if (numeroConta.isEmpty()) {
            txtResultado.setText("Informe o número da conta.");
            return;
        }

        String sqlConta = """
            SELECT id_conta, saldo, tipo_conta, status, data_abertura
            FROM conta
            WHERE numero_conta = ?
        """;

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlConta)) {

            stmt.setString(1, numeroConta);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int idConta = rs.getInt("id_conta");
                    String tipoConta = rs.getString("tipo_conta");
                    StringBuilder sb = new StringBuilder();

                    sb.append("=========== DADOS DA CONTA =======\n\n");
                    sb.append("Número da Conta: ").append(numeroConta).append("\n");
                    sb.append("Tipo: ").append(tipoConta).append("\n");
                    sb.append("Saldo: R$ ").append(rs.getBigDecimal("saldo")).append("\n");
                    sb.append("Status: ").append(rs.getString("status")).append("\n");
                    sb.append("Data de Abertura: ").append(rs.getTimestamp("data_abertura")).append("\n\n");

                    // Consulta complementar conforme o tipo da conta
                    switch (tipoConta) {
                        case "POUPANCA" -> consultarPoupanca(conn, idConta, sb);
                        case "CORRENTE" -> consultarCorrente(conn, idConta, sb);
                        case "INVESTIMENTO" -> consultarInvestimento(conn, idConta, sb);
                    }

                    txtResultado.setText(sb.toString());
                } else {
                    txtResultado.setText("Conta não encontrada.");
                }
            }

        } catch (SQLException e) {
            txtResultado.setText("Erro ao consultar conta.");
            e.printStackTrace();
        }
    }

    private void consultarPoupanca(Connection conn, int idConta, StringBuilder sb) throws SQLException {
        String sql = """
            SELECT taxa_rendimento, ultimo_rendimento
            FROM conta_poupanca
            WHERE id_conta = ?
        """;
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idConta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    sb.append("=== DETALHES CONTA POUPANÇA ===\n\n");
                    sb.append("Taxa de Rendimento: ").append(rs.getBigDecimal("taxa_rendimento")).append("%\n");
                    Timestamp rendimento = rs.getTimestamp("ultimo_rendimento");
                    sb.append("Último Rendimento: ").append(rendimento != null ? rendimento : "N/A").append("\n");
                }
            }
        }
    }

    private void consultarCorrente(Connection conn, int idConta, StringBuilder sb) throws SQLException {
        String sql = """
            SELECT limite, data_vencimento, taxa_manutencao
            FROM conta_corrente
            WHERE id_conta = ?
        """;
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idConta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    sb.append("=== DETALHES CONTA CORRENTE ===\n\n");
                    sb.append("Limite: R$ ").append(rs.getBigDecimal("limite")).append("\n");
                    sb.append("Data de Vencimento: ").append(rs.getDate("data_vencimento")).append("\n");
                    sb.append("Taxa de Manutenção: ").append(rs.getBigDecimal("taxa_manutencao")).append("%\n");
                }
            }
        }
    }

    private void consultarInvestimento(Connection conn, int idConta, StringBuilder sb) throws SQLException {
        String sql = """
            SELECT perfil_risco, valor_minimo, taxa_rendimento_base
            FROM conta_investimento
            WHERE id_conta = ?
        """;
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idConta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    sb.append("=== DETALHES CONTA INVESTIMENTO ===\n\n");
                    sb.append("Perfil de Risco: ").append(rs.getString("perfil_risco")).append("\n");
                    sb.append("Valor Mínimo: R$ ").append(rs.getBigDecimal("valor_minimo")).append("\n");
                    sb.append("Taxa Base de Rendimento: ").append(rs.getBigDecimal("taxa_rendimento_base")).append("%\n");
                }
            }
        }
    }

    @FXML private Button btnSair;

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
