package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.MD5Util;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.*;

public class funcionarioTelaCadastroUsuarioController {

    @FXML private TextField txtNome, txtCpf, txtTelefone, txtDataNascimento, txtOtpAtivo, txtOtpExpiracao;
    @FXML private PasswordField txtSenha;
    @FXML private ComboBox<String> comboTipoUsuario;
    @FXML private TextField txtCEP, txtLocal, txtNumeroCasa, txtBairro, txtCidade, txtEstado, txtComplemento;

    @FXML
    public void initialize() {
        comboTipoUsuario.getItems().addAll("FUNCIONARIO", "CLIENTE");
    }

    @FXML
    private void onLimparCampos() {
        txtNome.clear();
        txtCpf.clear();
        txtTelefone.clear();
        txtDataNascimento.clear();
        txtSenha.clear();
        comboTipoUsuario.getSelectionModel().clearSelection();
        txtOtpAtivo.clear();
        txtOtpExpiracao.clear();

        txtCEP.clear();
        txtLocal.clear();
        txtNumeroCasa.clear();
        txtBairro.clear();
        txtCidade.clear();
        txtEstado.clear();
        txtComplemento.clear();
    }

    @FXML
    private void onCadastrarUsuario() {
        String nome = txtNome.getText();
        String cpf = txtCpf.getText();
        String telefone = txtTelefone.getText();
        String dataNascimento = txtDataNascimento.getText();
        String tipoUsuario = comboTipoUsuario.getValue();
        String senhaHash = MD5Util.hashMD5(txtSenha.getText());
        String otpAtivo = txtOtpAtivo.getText();
        String otpExpiracao = txtOtpExpiracao.getText();

        String cep = txtCEP.getText();
        String local = txtLocal.getText();
        int numeroCasa = Integer.parseInt(txtNumeroCasa.getText());
        String bairro = txtBairro.getText();
        String cidade = txtCidade.getText();
        String estado = txtEstado.getText();
        String complemento = txtComplemento.getText();

        String sqlUsuario = "INSERT INTO usuario (nome, cpf, data_nascimento, telefone, tipo_usuario, senha_hash, otp_ativo, otp_expiracao) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlEndereco = "INSERT INTO endereco (id_usuario, cep, local, numero_casa, bairro, cidade, estado, complemento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtUsuario = conn.prepareStatement(sqlUsuario, PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmtUsuario.setString(1, nome);
                stmtUsuario.setString(2, cpf);
                stmtUsuario.setString(3, dataNascimento);
                stmtUsuario.setString(4, telefone);
                stmtUsuario.setString(5, tipoUsuario);
                stmtUsuario.setString(6, senhaHash);
                stmtUsuario.setString(7, otpAtivo.isEmpty() ? null : otpAtivo);
                stmtUsuario.setString(8, otpExpiracao.isEmpty() ? null : otpExpiracao);
                stmtUsuario.executeUpdate();

                var rs = stmtUsuario.getGeneratedKeys();
                if (rs.next()) {
                    int idUsuario = rs.getInt(1);

                    try (PreparedStatement stmtEndereco = conn.prepareStatement(sqlEndereco)) {
                        stmtEndereco.setInt(1, idUsuario);
                        stmtEndereco.setString(2, cep);
                        stmtEndereco.setString(3, local);
                        stmtEndereco.setInt(4, numeroCasa);
                        stmtEndereco.setString(5, bairro);
                        stmtEndereco.setString(6, cidade);
                        stmtEndereco.setString(7, estado);
                        stmtEndereco.setString(8, complemento);
                        stmtEndereco.executeUpdate();
                    }

                    conn.commit();
                    mostrarAlerta("Usuário cadastrado com sucesso!");
                    onLimparCampos();
                }
            } catch (SQLException e) {
                conn.rollback();
                mostrarAlertaErro("Erro ao cadastrar: " + e.getMessage());
            }
        } catch (SQLException e) {
            mostrarAlertaErro("Erro na conexão: " + e.getMessage());
        }
    }

    private void mostrarAlerta(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sucesso");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    private void mostrarAlertaErro(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText("Falha no cadastro");
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML private AnchorPane rootPane;
    @FXML private Button btnSair;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
