package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class funcTelaCadastrarFuncionarioController {

    @FXML private TextField txtIdUsuario;
    @FXML private TextField txtCodigoFuncionario;
    @FXML private ComboBox<String> comboDefinirCargo;
    @FXML private TextField txtIdSupervisor;
    @FXML private Button btnCriarFuncionario;

    @FXML
    public void initialize() {
        // Preenche o ComboBox com os cargos disponíveis
        comboDefinirCargo.setItems(FXCollections.observableArrayList("ESTAGIARIO", "ATENDENTE", "GERENTE"));
    }

    @FXML
    private void criarFuncionario() {
        String idUsuarioStr = txtIdUsuario.getText();
        String codigoFuncionario = txtCodigoFuncionario.getText();
        String cargo = comboDefinirCargo.getValue();
        String idSupervisorStr = txtIdSupervisor.getText();

        // Valida campos obrigatórios
        if (idUsuarioStr.isEmpty() || codigoFuncionario.isEmpty() || cargo == null) {
            mostrarErro("Preencha todos os campos obrigatórios (ID Usuário, Código e Cargo).");
            return;
        }

        try {
            int idUsuario = Integer.parseInt(idUsuarioStr);
            Integer idSupervisor = idSupervisorStr.isEmpty() ? null : Integer.parseInt(idSupervisorStr);

            String sql = "INSERT INTO funcionario (id_usuario, codigo_funcionario, cargo, id_supervisor) VALUES (?, ?, ?, ?)";

            try (Connection conn = Database.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, idUsuario);
                stmt.setString(2, codigoFuncionario);
                stmt.setString(3, cargo);

                if (idSupervisor != null) {
                    stmt.setInt(4, idSupervisor);
                } else {
                    stmt.setNull(4, java.sql.Types.INTEGER);
                }

                stmt.executeUpdate();
                mostrarSucesso("Funcionário cadastrado com sucesso!");
                limparCampos();
            }

        } catch (NumberFormatException e) {
            mostrarErro("ID do Usuário e ID do Supervisor devem ser numéricos.");
        } catch (SQLException e) {
            mostrarErro("Erro ao cadastrar funcionário: " + e.getMessage());
        }
    }

    private void limparCampos() {
        txtIdUsuario.clear();
        txtCodigoFuncionario.clear();
        comboDefinirCargo.getSelectionModel().clearSelection();
        txtIdSupervisor.clear();
    }

    private void mostrarSucesso(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sucesso");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    private void mostrarErro(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText("Ocorreu um problema");
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
