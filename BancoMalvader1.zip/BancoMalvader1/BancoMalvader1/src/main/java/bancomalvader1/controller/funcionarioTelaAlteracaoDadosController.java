package bancomalvader1.controller;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class funcionarioTelaAlteracaoDadosController {

    @FXML private Button btnAlterarConta;
    @FXML private Button btnAlterarUsuario;

    @FXML
    private void onAlterarConta() {
        VoltarUtils.guardarTela("/bancomalvader1/view/funcionarioTelaAlteracaoDados.fxml");

        carregarTela("/bancomalvader1/view/funcTelaAlterarConta.fxml", "Tela de Alterar Contas - Funcionário", btnAlterarConta);

        System.out.println("Abrindo tela de Alterar Contas...");
    }

    @FXML
    private void onAlterarUsuario() {
        VoltarUtils.guardarTela("/bancomalvader1/view/funcionarioTelaAlteracaoDados.fxml");

        carregarTela("/bancomalvader1/view/funcTelaAlterarUsuario.fxml", "Tela de Alterar Usuários - Funcionário", btnAlterarUsuario);

        System.out.println("Abrindo tela de Alterar Usuários...");
    }


    private void carregarTela(String acessartela, String title, Node botao) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(acessartela));
            Parent root = loader.load();

            Stage stage = (Stage) botao.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erro ao carregar a próxima tela.");
            e.printStackTrace();
        }
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
