package bancomalvader1.controller;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class menuFuncionarioController {

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;
    @FXML
    private Button btnAberturaConta;
    @FXML
    private Button btnEncerramentoConta;
    @FXML
    private Button btnConsultaDados;
    @FXML
    private Button btnAlteracaoDados;
    @FXML
    private Button btnCadastroUsuario;
    @FXML
    private Button btnCadastroCliente;
    @FXML
    private Button btnCadastroFuncionario;
    @FXML
    private Button btnRelatorios;

    @FXML
    private void acessarAberturaConta() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcionarioTelaAberturaConta.fxml", "Tela de Abertura de Contas - Funcionário", btnAberturaConta);

        System.out.println("Abrindo tela de Abertura de conta...");
    }

    @FXML
    private void acessarEncerramentoConta() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcionarioTelaEncerramentoConta.fxml", "Tela de Encerramento de Contas - Funcionário", btnEncerramentoConta);

        System.out.println("Abrindo tela de Encerramento de conta...");
    }

    @FXML
    private void acessarConsultaDados() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcionarioTelaConsultarDados.fxml", "Tela de Consulta de Dados - Funcionário", btnConsultaDados);

        System.out.println("Abrindo tela de consulta de dados...");
    }

    @FXML
    private void acessarAlteracaoDados() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcionarioTelaAlteracaoDados.fxml", "Tela de Alteração de Dados - Funcionário", btnAlteracaoDados);

        System.out.println("Abrindo tela de Alteração de Dados...");
    }

    @FXML
    private void acessarCadastroUsuario() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcionarioTelaCadastroUsuario.fxml", "Tela de Cadastro de Usuários - Funcionário", btnCadastroUsuario);

        System.out.println("Abrindo tela de Cadastro de Usuários...");
    }

    @FXML
    private void acessarCadastroCliente() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcTelaCadastrarCliente.fxml", "Tela de Cadastro de Clientes - Funcionário", btnCadastroCliente);

        System.out.println("Abrindo tela de Cadastro de Clientes...");
    }

    @FXML
    private void acessarCadastroFuncionario() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcTelaCadastrarFuncionario.fxml", "Tela de Cadastro de Funcionários - Funcionário", btnCadastroFuncionario);

        System.out.println("Abrindo tela de Cadastro de Funcionários...");
    }


    @FXML
    private void acessarRelatorios() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuFuncionario.fxml");

        carregarTela("/bancomalvader1/view/funcionarioTelaGeracaoRelatorios.fxml", "Tela de Geração de Relatórios - Funcionário", btnRelatorios);

        System.out.println("Abrindo tela de Relatorios...");
    }

    private void carregarTela(String acessartela, String title, Node botao) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(acessartela));
            Parent root = loader.load();

            Stage stage = (Stage) botao.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erro ao carregar a próxima tela.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
