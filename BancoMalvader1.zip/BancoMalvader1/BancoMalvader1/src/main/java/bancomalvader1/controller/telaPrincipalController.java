package bancomalvader1.controller;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class telaPrincipalController {

    @FXML
    private Button btnCliente;

    @FXML
    private Button btnFuncionario;

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnClienteClick() {
        try {
            VoltarUtils.guardarTela("/bancomalvader1/view/telaPrincipal.fxml");

            //trocar depois para a tela de login (Cliente)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/bancomalvader1/view/loginCliente.fxml"));
            Parent root = loader.load();

            // Obtém o stage atual
            Stage stage = (Stage) btnCliente.getScene().getWindow();

            // Define a nova cena
            stage.setScene(new Scene(root));
            stage.show();

            System.out.println("Tela de Login - (Cliente)");
        } catch (Exception e) {
            System.err.println("Erro ao carregar a tela de login do Cliente:");
            e.printStackTrace();
        }
    }

    @FXML
    private void onBtnFuncionarioClick() {
        try {
            VoltarUtils.guardarTela("/bancomalvader1/view/telaPrincipal.fxml");

            //Trocar depois para a tela de login (Funcionário)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/bancomalvader1/view/loginFuncionario.fxml"));
            Parent root = loader.load();

            // Obtém o stage atual
            Stage stage = (Stage) btnFuncionario.getScene().getWindow();

            // Define a nova cena
            stage.setScene(new Scene(root));
            stage.show();

            System.out.println("Tela de Login - (Funcionário)");

        } catch (Exception e) {
            System.err.println("Erro ao carregar a tela de login do Funcionário:");
            e.printStackTrace();
        }
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}