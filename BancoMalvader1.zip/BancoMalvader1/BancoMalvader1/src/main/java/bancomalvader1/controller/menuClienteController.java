package bancomalvader1.controller;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class menuClienteController {



    @FXML
    private Button btnSair;
    @FXML
    private Button btnSaldoCliente;
    @FXML
    private Button btnDeposito;
    @FXML
    private Button btnSaque;
    @FXML
    private Button btnExtrato;
    @FXML
    private Button btnLimite;
    @FXML
    private Button btnTransferencia;

    @FXML
    private void acessarSaldo() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuCliente.fxml");

        carregarTela("/bancomalvader1/view/clienteTelaSaldo.fxml", "Tela de Consultar Saldo - Cliente", btnSaldoCliente);

        System.out.println("Abrindo tela de Consultar Saldo do cliente...");
    }

    @FXML
    private void acessarDeposito() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuCliente.fxml");

        carregarTela("/bancomalvader1/view/clienteTelaDeposito.fxml", "Tela de Deposito - Cliente", btnDeposito);

        System.out.println("Abrindo tela de Deposito do cliente...");
    }

    @FXML
    private void acessarSaque() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuCliente.fxml");

        carregarTela("/bancomalvader1/view/clienteTelaSaque.fxml", "Tela de Saque - Cliente", btnSaque);

        System.out.println("Abrindo tela de Saque do cliente...");
    }

    @FXML
    private void acessarTransferencia() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuCliente.fxml");

        carregarTela("/bancomalvader1/view/clienteTelaTransferencia.fxml", "Tela de Transferencia - Cliente", btnTransferencia);

        System.out.println("Abrindo tela de Transferencia do cliente...");
    }

    @FXML
    private void acessarExtrato() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuCliente.fxml");

        carregarTela("/bancomalvader1/view/clienteTelaExtrato.fxml", "Tela de Extrato - Cliente", btnExtrato);

        System.out.println("Abrindo tela de Extrato do cliente...");
    }

    @FXML
    private void acessarLimite() {
        VoltarUtils.guardarTela("/bancomalvader1/view/menuCliente.fxml");

        carregarTela("/bancomalvader1/view/clienteTelaConsultarLimite.fxml", "Tela de Consultar Limite - Cliente", btnLimite);

        System.out.println("Abrindo tela de Consultar Limite do cliente...");
    }

    private void carregarTela(String acessartela, String title, Node botao) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(acessartela));
            Parent root = loader.load();

            Stage stage = (Stage) botao.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erro ao carregar a próxima tela.");
            e.printStackTrace();
        }
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
