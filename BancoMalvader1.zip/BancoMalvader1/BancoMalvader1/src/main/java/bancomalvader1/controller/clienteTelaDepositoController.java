package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;

public class clienteTelaDepositoController {

    @FXML private TextField txtContaDeposito;
    @FXML private TextField txtValorDeposito;
    @FXML private Label    lblResultadoSaldo;
    @FXML private Button   btnConfirmarDeposito;

    @FXML
    private void initialize() {
        btnConfirmarDeposito.setOnAction(e -> confirmarDeposito());
    }

    private void confirmarDeposito() {
        String numeroConta = txtContaDeposito.getText().trim();
        String valorStr    = txtValorDeposito.getText().trim();

        if (numeroConta.isEmpty() || valorStr.isEmpty()) {
            alertErro("Preencha todos os campos.");
            return;
        }

        double valorDeposito;
        try {
            valorDeposito = Double.parseDouble(valorStr.replace(",", "."));
            if (valorDeposito <= 0) {
                alertErro("O valor do depósito deve ser maior que zero.");
                return;
            }
        } catch (NumberFormatException ex) {
            alertErro("Valor inválido. Use ponto ou vírgula como separador decimal.");
            return;
        }

        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

        String sqlSelect = "SELECT saldo FROM conta WHERE numero_conta = ? AND status = 'ATIVA' FOR UPDATE";
        String sqlUpdate = "UPDATE conta SET saldo = ? WHERE numero_conta = ?";

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement psSel = conn.prepareStatement(sqlSelect)) {
                psSel.setString(1, numeroConta);
                ResultSet rs = psSel.executeQuery();

                if (!rs.next()) {
                    conn.rollback();
                    alertErro("Conta não encontrada ou inativa.");
                    return;
                }

                double saldoAtual = rs.getDouble("saldo");
                double novoSaldo  = saldoAtual + valorDeposito;

                try (PreparedStatement psUpd = conn.prepareStatement(sqlUpdate)) {
                    psUpd.setDouble(1, novoSaldo);
                    psUpd.setString(2, numeroConta);
                    psUpd.executeUpdate();
                }

                conn.commit();
                lblResultadoSaldo.setText("Saldo: " + nf.format(novoSaldo));
                alertInfo("Depósito realizado com sucesso!");
                limparCampos();

            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException ex) {
            alertErro("Erro no banco de dados: " + ex.getMessage());
        }
    }

    private void limparCampos() {
        txtContaDeposito.clear();
        txtValorDeposito.clear();
    }

    private void alertInfo(String msg) {
        showAlert(Alert.AlertType.INFORMATION, "Sucesso", msg);
    }

    private void alertErro(String msg) {
        showAlert(Alert.AlertType.ERROR, "Erro", msg);
    }

    private void showAlert(Alert.AlertType tipo, String titulo, String msg) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
