package bancomalvader1.controller;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class funcionarioTelaConsultarDadosController {

    @FXML private Button btnConsultarContas;
    @FXML private Button btnConsultarFuncionarios;
    @FXML private Button btnConsultarClientes;

    @FXML
    private void acessarConsultarContas() {
        VoltarUtils.guardarTela("/bancomalvader1/view/funcionarioTelaConsultarDados.fxml");

        carregarTela("/bancomalvader1/view/funcTelaConsultarContas.fxml", "Tela de Consultar Contas - Funcionário", btnConsultarContas);

        System.out.println("Abrindo tela de Consultar Contas...");
    }

    @FXML
    private void acessarConsultarFuncionarios() {
        VoltarUtils.guardarTela("/bancomalvader1/view/funcionarioTelaConsultarDados.fxml");

        carregarTela("/bancomalvader1/view/funcTelaConsultarFuncionarios.fxml", "Tela de Consultar Funcionarios - Funcionário", btnConsultarFuncionarios);

        System.out.println("Abrindo tela de Consultar Funcionarios...");
    }

    @FXML
    private void acessarConsultarClientes() {
        VoltarUtils.guardarTela("/bancomalvader1/view/funcionarioTelaConsultarDados.fxml");

        carregarTela("/bancomalvader1/view/funcTelaConsultarClientes.fxml", "Tela de Consultar Clientes - Funcionário", btnConsultarClientes);

        System.out.println("Abrindo tela de Consultar Clientes...");
    }

    private void carregarTela(String acessartela, String title, Node botao) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(acessartela));
            Parent root = loader.load();

            Stage stage = (Stage) botao.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erro ao carregar a próxima tela.");
            e.printStackTrace();
        }
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
