package bancomalvader1.controller;

import bancomalvader1.util.AuthService;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class loginFuncionarioController{

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML private TextField cpfField;
    @FXML private TextField senhaField;

    @FXML
    private void handleLogin() {
        String cpf = cpfField.getText();
        String senha = senhaField.getText();

        if (AuthService.verificarLogin(cpf, senha)) {
            String tipoUsuario = AuthService.getTipoUsuario(cpf);

            if ("FUNCIONARIO".equals(tipoUsuario)) {
                VoltarUtils.guardarTela("/bancomalvader1/view/loginFuncionario.fxml");
                System.out.println("Login de funcionário realizado com sucesso! CPF: " + cpf);

                carregarTela("/bancomalvader1/view/menuFuncionario.fxml", "Menu Funcionário");

                System.out.println("Abrindo tela de menu do funcionário...");
            } else {
                System.out.println("Acesso permitido apenas para clientes.");
                System.out.println("Tentativa de acesso como cliente na tela de funcionário. CPF: " + cpf);
            }
        } else {
            System.out.println("CPF ou senha incorretos!");
            System.out.println("Tentativa de login de cliente falhou para CPF: " + cpf);
        }
    }

    private void carregarTela(String menufxml, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(menufxml));
            Parent root = loader.load();

            Stage stage = (Stage) cpfField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erro ao carregar a próxima tela.");
        }
    }

}