package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Random;

public class funcionarioTelaAberturaContaController {

    @FXML private TextField txtIdCliente;
    @FXML private TextField txtIdAgencia;
    @FXML private ComboBox<String> comboTipoConta;
    @FXML private TextField txtSaldo;
    @FXML private Button btnCriarConta;
    @FXML private Button btnSair;

    @FXML
    public void initialize() {
        comboTipoConta.getItems().addAll("CORRENTE", "POUPANCA", "INVESTIMENTO");
        btnCriarConta.setOnAction(event -> criarConta());
    }

    private void criarConta() {
        String idClienteStr = txtIdCliente.getText().trim();
        String idAgenciaStr = txtIdAgencia.getText().trim();
        String tipoConta = comboTipoConta.getValue();
        String saldoStr = txtSaldo.getText().trim();

        if (idClienteStr.isEmpty() || idAgenciaStr.isEmpty() || tipoConta == null || saldoStr.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Campos obrigatórios não preenchidos.");
            return;
        }

        try {
            int idCliente = Integer.parseInt(idClienteStr);
            int idAgencia = Integer.parseInt(idAgenciaStr);
            double saldo = Double.parseDouble(saldoStr);
            String numeroConta = gerarNumeroContaComDV();

            String sql = """
                INSERT INTO conta (numero_conta, id_agencia, saldo, tipo_conta, id_cliente)
                VALUES (?, ?, ?, ?, ?)
            """;

            try (Connection conn = Database.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, numeroConta);
                stmt.setInt(2, idAgencia);
                stmt.setDouble(3, saldo);
                stmt.setString(4, tipoConta);
                stmt.setInt(5, idCliente);

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Conta criada com sucesso!\nNúmero: " + numeroConta);
                    limparCampos();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Falha ao criar conta.");
                }
            }

        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "ID da agência, cliente e saldo devem ser numéricos.");
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String gerarNumeroContaComDV() {
        Random random = new Random();
        int corpo = 10000000 + random.nextInt(90000000); // Gera número de 8 dígitos
        int dv = calcularDigitoVerificador(corpo);
        return corpo + "-" + dv;
    }

    private int calcularDigitoVerificador(int numero) {
        int soma = 0;
        int multiplicador = 2;
        int n = numero;

        while (n > 0) {
            int digito = n % 10;
            soma += digito * multiplicador;
            multiplicador++;
            n /= 10;
        }

        int resto = soma % 11;
        int dv = 11 - resto;
        if (dv >= 10) dv = 0;
        return dv;
    }

    private void limparCampos() {
        txtIdCliente.clear();
        txtIdAgencia.clear();
        txtSaldo.clear();
        comboTipoConta.setValue(null);
    }

    @FXML
    private void onLimparCampos() {
        limparCampos();
    }

    private void showAlert(Alert.AlertType tipo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.setTitle("Abertura de Conta");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
