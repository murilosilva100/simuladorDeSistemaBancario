package bancomalvader1.controller;

import bancomalvader1.util.AuthService;
import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class OTPVerificationController {

    @FXML private TextField otpField;
    @FXML private TextField cpfField;
    @FXML private Button btnVerificarOTP;
    @FXML private Button btnReenviarOTP;
    @FXML private Button btnSair;

    private int userId;
    private String generatedOTP;
    private long otpExpirationTime;

    private String userType;

    @FXML
    public void initialize() {
        // Configura validação para aceitar apenas números (6 dígitos)
        otpField.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                otpField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (newValue.length() > 6) {
                otpField.setText(oldValue);
            }
        });
    }

    // Método para configurar o usuário (chamado ao abrir a tela)
    public void setUserId(int userId) {
        this.userId = userId;
        generateNewOTP();
    }

    @FXML
    private void onBtnVerificarOTP() throws IOException {
        String enteredOTP = otpField.getText().trim();

        if (enteredOTP.length() != 6) {
            System.out.println("[ERRO] O código deve ter 6 dígitos");
            return;
        }

        if (System.currentTimeMillis() > otpExpirationTime) {
            System.out.println("[ERRO] Código expirado. Gere um novo.");
            return;
        }

        if (enteredOTP.equals(generatedOTP)) {
            System.out.println("[SUCESSO] OTP verificado com sucesso!");
            closeWindow();

            carregarTela("/bancomalvader1/view/menuCliente.fxml", "Menu CLiente", btnVerificarOTP);

        } else {
            System.out.println("[ERRO] Código OTP inválido");
        }
    }

    @FXML
    private void onBtnReenviarOTP() {
        generateNewOTP();
    }

    private void generateNewOTP() {
        try (Connection conn = Database.getConnection();
             CallableStatement stmt = conn.prepareCall("{call gerar_otp(?)}")) {

            stmt.setInt(1, userId);
            stmt.execute();

            try (ResultSet rs = stmt.getResultSet()) {
                if (rs.next()) {
                    generatedOTP = rs.getString(1);
                    otpExpirationTime = System.currentTimeMillis() + (5 * 60 * 1000); // 5 minutos

                    System.out.println("----------------------------------");
                    System.out.println("NOVO OTP GERADO: " + generatedOTP);
                    System.out.println("Válido até: " + new java.util.Date(otpExpirationTime));
                    System.out.println("----------------------------------");

                    // Este metodo está falhando em gerar o OTP via procedure.
                }
            }
        } catch (SQLException e) {
            //System.out.println("[ERRO] Falha ao gerar OTP: ");
            // Fallback: geração local se a procedure falhar

            // Aqui o OTP está sendo gerado localmente, randômico.
            generatedOTP = String.format("%06d", (int)(Math.random() * 1000000));
            otpExpirationTime = System.currentTimeMillis() + (5 * 60 * 1000);
            System.out.println("OTP GERADO LOCALMENTE: " + generatedOTP);
        }
    }

    private void closeWindow() {
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

    private void carregarTela(String acessartela, String title, Node botao) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(acessartela));
            Parent root = loader.load();

            Stage stage = (Stage) botao.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            System.out.println("Erro ao carregar a próxima tela.");
            e.printStackTrace();
        }
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private void onBtnSairClick() {
        System.out.println("[INFO] Operação cancelada pelo usuário");
        closeWindow();
    }
}