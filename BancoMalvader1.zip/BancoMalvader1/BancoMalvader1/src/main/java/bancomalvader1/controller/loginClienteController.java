package bancomalvader1.controller;

import bancomalvader1.util.AuthService;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.layout.AnchorPane;
import java.io.IOException;

import javafx.scene.control.TextField;
import lombok.Getter;
import lombok.Setter;

public class loginClienteController{

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML private TextField cpfField;

    @FXML private TextField senhaField;
    @FXML private Button btnEntrar;

    @FXML
    private void handleLogin() throws IOException {
        String cpf = cpfField.getText();
        String senha = senhaField.getText();

        if (AuthService.verificarLogin(cpf, senha)) {
            String tipoUsuario = AuthService.getTipoUsuario(cpf);

            if ("CLIENTE".equals(tipoUsuario)) {
                VoltarUtils.guardarTela("/bancomalvader1/view/loginCliente.fxml");

                int userId = AuthService.getUserIdByCpf(cpf);

                closeWindow();

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/bancomalvader1/view/verificationOTP.fxml"));
                Parent root = loader.load();

                OTPVerificationController controller = loader.getController();
                controller.setUserId(userId); // Configura o usuário

                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.setTitle("Verificação OTP");
                stage.show();

            } else {
                System.out.println("Acesso permitido apenas para clientes.");
                System.out.println("Tentativa de acesso como cliente na tela de funcionário. CPF: " + cpf);
            }
        } else {
            System.out.println("CPF ou senha incorretos!");
            System.out.println("Tentativa de login de cliente falhou para CPF: " + cpf);
        }
    }

    private void closeWindow() {
        Stage stage = (Stage) btnEntrar.getScene().getWindow();
        stage.close();
    }
}
