package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class funcionarioTelaEncerramentoContaController {

    @FXML private TextField txtNumeroConta;
    @FXML private PasswordField txtSenhaAdmin;
    @FXML private TextField txtOtp;
    @FXML private TextField txtMotivo;
    @FXML private Button btnEncerrarConta;
    @FXML private Button btnLimparCampos;

    @FXML
    private void initialize() {
        btnEncerrarConta.setOnAction(this::onEncerrarConta);
    }

    private void onEncerrarConta(ActionEvent event) {
        String numeroConta = txtNumeroConta.getText();
        String senhaAdmin = txtSenhaAdmin.getText();
        String otp = txtOtp.getText();
        String motivo = txtMotivo.getText();

        if (numeroConta.isEmpty() || senhaAdmin.isEmpty() || otp.isEmpty() || motivo.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Preencha todos os campos.");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            // Verifica se a conta existe e está ativa
            String sqlConta = "SELECT id_conta, status FROM conta WHERE numero_conta = ?";
            PreparedStatement stmtConta = conn.prepareStatement(sqlConta);
            stmtConta.setString(1, numeroConta);
            ResultSet rs = stmtConta.executeQuery();

            if (!rs.next()) {
                showAlert(Alert.AlertType.ERROR, "Conta não encontrada.");
                return;
            }

            int idConta = rs.getInt("id_conta");
            String status = rs.getString("status");

            if (!"ATIVA".equals(status)) {
                showAlert(Alert.AlertType.WARNING, "A conta já está encerrada ou bloqueada.");
                return;
            }

            // Verifica se o admin está autenticado
            String sqlAdmin = "SELECT * FROM usuario WHERE tipo_usuario = 'FUNCIONARIO' AND senha_hash = MD5(?) AND otp_ativo = ?";
            PreparedStatement stmtAdmin = conn.prepareStatement(sqlAdmin);
            stmtAdmin.setString(1, senhaAdmin);
            stmtAdmin.setString(2, otp);
            ResultSet rsAdmin = stmtAdmin.executeQuery();

            if (!rsAdmin.next()) {
                showAlert(Alert.AlertType.ERROR, "Senha ou OTP inválido.");
                return;
            }

            // Atualiza status da conta
            String sqlUpdate = "UPDATE conta SET status = 'ENCERRADA' WHERE id_conta = ?";
            PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate);
            stmtUpdate.setInt(1, idConta);
            stmtUpdate.executeUpdate();

            // Insere no histórico
            String sqlHistorico = "INSERT INTO historico (id_conta, evento) VALUES (?, 'ENCERRAMENTO')";
            PreparedStatement stmtHistorico = conn.prepareStatement(sqlHistorico);
            stmtHistorico.setInt(1, idConta);
            stmtHistorico.executeUpdate();

            showAlert(Alert.AlertType.INFORMATION, "Conta encerrada com sucesso.");
            limparCampos();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erro ao encerrar a conta: " + e.getMessage());
        }
    }

    @FXML
    private void onLimparCampos(ActionEvent event) {
        limparCampos();
    }

    private void limparCampos() {
        txtNumeroConta.clear();
        txtSenhaAdmin.clear();
        txtOtp.clear();
        txtMotivo.clear();
    }

    private void showAlert(Alert.AlertType tipo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.setTitle("Encerramento de Conta");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
