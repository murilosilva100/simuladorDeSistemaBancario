package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;

public class clienteTelaSaqueController {

    @FXML private TextField txtNumeroConta;
    @FXML private TextField txtValorSaque;
    @FXML private Label lblResultadoSaldo;
    @FXML private Button btnConfirmarSaque;

    @FXML
    private void initialize() {
        btnConfirmarSaque.setOnAction(e -> realizarSaque());
    }

    private void realizarSaque() {
        String numeroConta = txtNumeroConta.getText().trim();
        String valorStr = txtValorSaque.getText().trim();

        if (numeroConta.isEmpty() || valorStr.isEmpty()) {
            alertErro("Preencha todos os campos.");
            return;
        }

        double valorSaque;
        try {
            valorSaque = Double.parseDouble(valorStr.replace(",", "."));
            if (valorSaque <= 0) {
                alertErro("O valor do saque deve ser maior que zero.");
                return;
            }
        } catch (NumberFormatException e) {
            alertErro("Valor inválido. Use ponto ou vírgula como separador decimal.");
            return;
        }

        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

        String sqlSelect = "SELECT saldo FROM conta WHERE numero_conta = ? AND status = 'ATIVA' FOR UPDATE";
        String sqlUpdate = "UPDATE conta SET saldo = ? WHERE numero_conta = ?";

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement psSel = conn.prepareStatement(sqlSelect)) {
                psSel.setString(1, numeroConta);
                ResultSet rs = psSel.executeQuery();

                if (!rs.next()) {
                    conn.rollback();
                    alertErro("Conta não encontrada ou inativa.");
                    return;
                }

                double saldoAtual = rs.getDouble("saldo");

                if (valorSaque > saldoAtual) {
                    conn.rollback();
                    alertErro("Saldo insuficiente para saque.");
                    return;
                }

                double novoSaldo = saldoAtual - valorSaque;

                try (PreparedStatement psUpd = conn.prepareStatement(sqlUpdate)) {
                    psUpd.setDouble(1, novoSaldo);
                    psUpd.setString(2, numeroConta);
                    psUpd.executeUpdate();
                }

                conn.commit();
                lblResultadoSaldo.setText("Saldo: " + nf.format(novoSaldo));
                alertInfo("Saque realizado com sucesso!");
                limparCampos();

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }

        } catch (SQLException e) {
            alertErro("Erro ao acessar o banco de dados: " + e.getMessage());
        }
    }

    private void limparCampos() {
        txtNumeroConta.clear();
        txtValorSaque.clear();
    }

    private void alertInfo(String msg) {
        showAlert(Alert.AlertType.INFORMATION, "Sucesso", msg);
    }

    private void alertErro(String msg) {
        showAlert(Alert.AlertType.ERROR, "Erro", msg);
    }

    private void showAlert(Alert.AlertType tipo, String titulo, String msg) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
