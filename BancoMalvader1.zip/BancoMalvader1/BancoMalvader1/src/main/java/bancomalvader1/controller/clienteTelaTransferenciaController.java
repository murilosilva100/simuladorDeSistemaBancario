package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;

public class clienteTelaTransferenciaController {

    @FXML private TextField txtContaOrigem;
    @FXML private TextField txtSenha;
    @FXML private TextField txtContaDestino;
    @FXML private TextField txtValorTransferencia;
    @FXML private Button btnTransferir;

    @FXML
    private void initialize() {
        btnTransferir.setOnAction(e -> realizarTransferencia());
    }

    private void realizarTransferencia() {
        String contaOrigem = txtContaOrigem.getText().trim();
        String senha = txtSenha.getText().trim();
        String contaDestino = txtContaDestino.getText().trim();
        String valorStr = txtValorTransferencia.getText().trim();

        if (contaOrigem.isEmpty() || senha.isEmpty() || contaDestino.isEmpty() || valorStr.isEmpty()) {
            alertErro("Preencha todos os campos.");
            return;
        }

        double valor;
        try {
            valor = Double.parseDouble(valorStr.replace(",", "."));
            if (valor <= 0) {
                alertErro("Valor deve ser maior que zero.");
                return;
            }
        } catch (NumberFormatException e) {
            alertErro("Valor inválido.");
            return;
        }

        String sqlContaOrigem = "SELECT c.saldo, u.senha_hash " +
                "FROM conta c " +
                "JOIN cliente cl ON c.id_cliente = cl.id_cliente " +
                "JOIN usuario u ON cl.id_usuario = u.id_usuario " +
                "WHERE c.numero_conta = ? AND c.status = 'ATIVA' FOR UPDATE";

        String sqlContaDestino = "SELECT saldo FROM conta WHERE numero_conta = ? AND status = 'ATIVA' FOR UPDATE";

        String sqlUpdateSaldo = "UPDATE conta SET saldo = ? WHERE numero_conta = ?";

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);

            try (
                    PreparedStatement psOrigem = conn.prepareStatement(sqlContaOrigem);
                    PreparedStatement psDestino = conn.prepareStatement(sqlContaDestino)
            ) {
                // Verifica conta de origem
                psOrigem.setString(1, contaOrigem);
                ResultSet rsOrigem = psOrigem.executeQuery();
                if (!rsOrigem.next()) {
                    conn.rollback();
                    alertErro("Conta de origem inválida ou inativa.");
                    return;
                }

                double saldoOrigem = rsOrigem.getDouble("saldo");
                String senhaHash = rsOrigem.getString("senha_hash");

                if (!senhaHash.equalsIgnoreCase(md5(senha))) {
                    conn.rollback();
                    alertErro("Senha incorreta.");
                    return;
                }

                if (saldoOrigem < valor) {
                    conn.rollback();
                    alertErro("Saldo insuficiente.");
                    return;
                }

                // Verifica conta de destino
                psDestino.setString(1, contaDestino);
                ResultSet rsDestino = psDestino.executeQuery();
                if (!rsDestino.next()) {
                    conn.rollback();
                    alertErro("Conta de destino inválida ou inativa.");
                    return;
                }

                double saldoDestino = rsDestino.getDouble("saldo");

                double novoSaldoOrigem = saldoOrigem - valor;
                double novoSaldoDestino = saldoDestino + valor;

                // Atualiza saldo origem
                try (PreparedStatement psUpd1 = conn.prepareStatement(sqlUpdateSaldo);
                     PreparedStatement psUpd2 = conn.prepareStatement(sqlUpdateSaldo)) {

                    psUpd1.setDouble(1, novoSaldoOrigem);
                    psUpd1.setString(2, contaOrigem);
                    psUpd1.executeUpdate();

                    psUpd2.setDouble(1, novoSaldoDestino);
                    psUpd2.setString(2, contaDestino);
                    psUpd2.executeUpdate();
                }

                conn.commit();

                NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
                alertInfo("Transferência realizada com sucesso!\nNovo saldo: " + nf.format(novoSaldoOrigem));
                limparCampos();
            } catch (SQLException e) {
                conn.rollback();
                alertErro("Erro ao transferir: " + e.getMessage());
            }

        } catch (SQLException e) {
            alertErro("Erro de conexão: " + e.getMessage());
        }
    }

    private String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest)
                sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return "";
        }
    }

    private void limparCampos() {
        txtContaOrigem.clear();
        txtSenha.clear();
        txtContaDestino.clear();
        txtValorTransferencia.clear();
    }

    private void alertErro(String msg) {
        showAlert(Alert.AlertType.ERROR, "Erro", msg);
    }

    private void alertInfo(String msg) {
        showAlert(Alert.AlertType.INFORMATION, "Sucesso", msg);
    }

    private void showAlert(Alert.AlertType tipo, String titulo, String msg) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }
}
