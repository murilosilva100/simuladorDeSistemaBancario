package bancomalvader1.controller;

import bancomalvader1.util.Database;
import bancomalvader1.util.VoltarUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class funcTelaAlterarContaController {

    @FXML private TextField txtNumeroConta;
    @FXML private TextField txtIdAgencia;
    @FXML private ComboBox<String> comboTipoConta;
    @FXML private ComboBox<String> comboStatus;
    @FXML private Button btnAlterarDados;
    @FXML private Button btnLimparCampos;

    @FXML
    public void initialize() {
        ObservableList<String> tiposConta = FXCollections.observableArrayList("POUPANCA", "CORRENTE", "INVESTIMENTO");
        comboTipoConta.setItems(tiposConta);

        ObservableList<String> statusConta = FXCollections.observableArrayList("ATIVA", "BLOQUEADA");
        comboStatus.setItems(statusConta);

        btnAlterarDados.setOnAction(this::onAlterarDados);
    }

    private void onAlterarDados(ActionEvent event) {
        String numeroConta = txtNumeroConta.getText();
        String tipoConta = comboTipoConta.getValue();
        String status = comboStatus.getValue();

        if (numeroConta.isEmpty() || tipoConta == null || status == null) {
            mostrarAlerta(Alert.AlertType.WARNING, "Preencha todos os campos obrigatórios.");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            // Verifica se a conta existe
            String sqlVerifica = "SELECT id_conta FROM conta WHERE numero_conta = ?";
            PreparedStatement stmtVerifica = conn.prepareStatement(sqlVerifica);
            stmtVerifica.setString(1, numeroConta);
            ResultSet rs = stmtVerifica.executeQuery();

            if (!rs.next()) {
                mostrarAlerta(Alert.AlertType.ERROR, "Conta não encontrada.");
                return;
            }

            int idConta = rs.getInt("id_conta");

            // Atualiza os dados da conta
            String sqlUpdate = "UPDATE conta SET tipo_conta = ?, status = ? WHERE id_conta = ?";
            PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate);
            stmtUpdate.setString(1, tipoConta);
            stmtUpdate.setString(2, status);
            stmtUpdate.setInt(3, idConta);
            int rowsAffected = stmtUpdate.executeUpdate();

            if (rowsAffected > 0) {
                mostrarAlerta(Alert.AlertType.INFORMATION, "Conta atualizada com sucesso.");
                limparCampos();
            } else {
                mostrarAlerta(Alert.AlertType.ERROR, "Erro ao atualizar a conta.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta(Alert.AlertType.ERROR, "Erro ao conectar ao banco de dados.");
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.setTitle("Aviso");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    @FXML
    private void onLimparCampos() {
        limparCampos();
    }

    private void limparCampos() {
        txtNumeroConta.clear();
        comboTipoConta.getSelectionModel().clearSelection();
        comboStatus.getSelectionModel().clearSelection();
        txtIdAgencia.clear();
    }


    @FXML
    private AnchorPane rootPane;

    @FXML
    private void voltarTela() {
        VoltarUtils.voltar(rootPane);
    }

    @FXML
    private Button btnSair;

    @FXML
    private void onBtnSairClick() {
        System.out.println("Saindo do sistema...");
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

}
