package bancomalvader1.application;

import bancomalvader1.util.Database;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {

            // Carrega o FXML da tela principal
            Parent root = FXMLLoader.load(getClass().getResource("/bancomalvader1/view/telaPrincipal.fxml"));
            Scene scene = new Scene(root);

            primaryStage.setTitle("Banco Malvader - Tela Principal");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        // if else para identificar o estabelecimento da conexão
        if (Database.isConnected()) {
            System.out.println("Conectado ao MySQL com sucesso!");
        } else {
            System.out.println("Falha ao conectar ao MySQL.");
        }
        launch(args);
    }
}